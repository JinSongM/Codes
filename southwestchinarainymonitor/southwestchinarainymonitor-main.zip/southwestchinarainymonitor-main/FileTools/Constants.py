#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
   @Project   ：Wiztek.MountainTorrent.SouthWestChina.Py 
   
   @File      ：Constants.py
   
   @Author    ：yhaoxian
   
   @Date      ：2022/3/23 19:54 
   
   @Describe  : 
   
"""
